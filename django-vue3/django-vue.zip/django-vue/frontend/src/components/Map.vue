<template>
<div>
  
    <h1>Mapping</h1>
 <button v-on:click="greet('Map')">OverView</button>
 <p>{{SingleDrone}}</p>
  <div style="display:flex;  justify-content: space-evenly;" >
   <div style="display:flex; flex-direction: column;  justify-content: space-about; height: 150px">
      <v-btn v-on:click="PostMQTT">
         <span left>UAV On </span>
          </v-btn>
          <v-btn v-on:click="PostMQTT">
         <span left>UAV Off </span>
          </v-btn>
   </div>
           <v-btn>
       <span left>TEST UAV {{SingleDrone}}</span>
        </v-btn>
           <v-btn>
       <span left>Alarmregion 1 </span>
        </v-btn>
           <v-btn>
       <span left>Alarmregion 2 </span>
        </v-btn>
          <v-btn style="height: 200px">
       <span style="color:red" left>NOTLANDUNG </span>
        </v-btn>
   
  </div>


  <div style="width: 100%; display:flex; margin-top:10vh">
      <GmapMap
      :center="{lat:52.5333973, lng:13.2595595}"
      :zoom="17"
      map-type-id="satellite"
      style="width: 50vw; height:50vh"></GmapMap>
      <div style="height:50vh; width: 20vw; background-color:black; color:white">
        <p>Console</p>
      </div>
  </div>
    <GmapMarker
      :key="index"
      v-for="(m, index) in markers"
      :position="m.position"
      :clickable="true"
      :draggable="false"
      @click="center=m.position"/>
      <div style="height:20vh"></div>
  </div>

  
  





</template>

<script>
 import axios from 'axios';
 export default {
  name: 'App',
  props: ['SingleDrone'],

  data: () => ({
  }),
  
   methods: {    
      greet: function(rowID){
      this.$emit('GoToMap', 'Map')       
      },
    async PostMQTT(){
      const res = await axios.get('http://localhost:8000/drones/PublishMQTT', {
    params: {
      Topic: this.SingleDrone,
      Msg: "UAV On"
    }
  })
      
    }
  },
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h1, h2 {
  font-weight: normal;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
