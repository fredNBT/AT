<template>
  <v-container>
      <p>Main Part </p>
  </v-container>
</template>

<script>
export default {
  name: 'Comp1',

  data: () => ({
  })
};
</script>
