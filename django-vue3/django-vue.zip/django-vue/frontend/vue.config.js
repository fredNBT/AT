module.exports = {
  "transpileDependencies": [
    "vuetify"
   
  ]
}