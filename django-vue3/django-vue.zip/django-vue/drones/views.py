from django.http import HttpResponse
from .models import Drone
from django.http import JsonResponse
from django.core import serializers
from rest_framework.decorators import api_view
from .serializers import DroneSerializers
import json
import paho.mqtt.client as mqtt #import the client1

def index(request):
    qs = Drone.objects.all()
    serializer = DroneSerializers(qs, many=True)
    return JsonResponse(serializer.data, safe=False)
    #return HttpResponse(json.dumps(qs[0]))

def detail(request, id):
   
    return HttpResponse(qs[1].Name)


@api_view(['GET'])
def private(request):
    qs = Drone.objects.values()
    print("QS",qs[0])
    #qs = Drone.objects.all()
    #qs_json = serializers.serialize('json', qs)
    return HttpResponse(json.dumps(qs[0]))


#@api_view(['GET'])
def PublishMQTT(request):
    Topic = request.GET.get('Topic', '')
    Msg = request.GET.get('Msg', '')
    client.publish(Topic,Msg, qos=1)
    print(Topic, Msg)
    print("PublishMQTT")
    return HttpResponse("Published Mqtt")


    ############
def on_message(client, userdata, message):
    print("message received " ,str(message.payload.decode("utf-8")))
    print("message topic=",message.topic)
    print("message qos=",message.qos)
    print("message retain flag=",message.retain)
########################################

broker_address="78.47.164.96"
#broker_address="iot.eclipse.org"
print("creating new instance")
client = mqtt.Client("P1") #create new instance
client.on_message=on_message #attach function to callback
print("connecting to broker")
client.connect(broker_address) #connect to broker
client.loop_start() #start the loop
print("Subscribing to topic","test")
client.subscribe("test")
print("Publishing message to topic","test")
client.publish("test","Message sent to test topic")