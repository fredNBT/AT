from django.db import models

class Drone(models.Model):
    Name        = models.TextField()
    Description = models.TextField()
    LastOrder = models.TextField()
    LastOrderTime = models.TextField()

class Logs(models.Model):
    id          = models.IntegerField(primary_key=True)
    Drone_id   = models.IntegerField(null=True)
    Origin        = models.TextField(null=True)
    Msg = models.TextField(null=True)
    MsgTime = models.DateTimeField(null=True)
