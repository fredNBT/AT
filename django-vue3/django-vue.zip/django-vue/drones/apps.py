from django.apps import AppConfig


class DronesConfig(AppConfig):
    name = 'drones'
